using Terraria.ModLoader;

namespace GoreGalore
{
	class GoreGalore : Mod
	{
		public GoreGalore()
		{
			Properties = new ModProperties()
			{
				Autoload = true,
				AutoloadGores = true,
				AutoloadSounds = true
			};
		}
	}
}
