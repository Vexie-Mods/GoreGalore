﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace GoreGalore
{
    class GorePlayer : ModPlayer
    {
        private const float ANGLE_RIGHT = 0.0f;
        private const float ANGLE_DOWN = (float)System.Math.PI / 2;
        private const float ANGLE_LEFT = (float)System.Math.PI;
        private const float ANGLE_UP = (float)(3 * System.Math.PI / 2);

        private const float ANGLE_DOWN_RIGHT = (float)System.Math.PI / 4;
        private const float ANGLE_DOWN_LEFT = (float)(3 * System.Math.PI / 4);
        private const float ANGLE_UP_LEFT = (float)(5 * System.Math.PI / 4);
        private const float ANGLE_UP_RIGHT = (float)(7 * System.Math.PI / 4);

        // Reload the configuration on entering the world
        // Used to test preferred gore levels
        public override void OnEnterWorld(Player player)
        {
            Config.Load();
            base.OnEnterWorld(player);
        }

        // Generic code to handle projectile attacking an entity
        // Blood will splat towards the projectile at a speed correlated to the velocity of the projectile
        public static void ProjectileAttackEntity(Mod mod, Projectile projectile, Entity entity, bool crit)
        {
            // Randomize scale of velocity
            float scaleVel = Main.rand.NextFloat(-0.5f, -0.1f);
            Vector2 pos = projectile.position;

            const int SIZE_ONE_BLOCK = 16;

            // Width of the blood splat has to be negative if the projectile strikes the right side of the NPC
            int width = projectile.position.X < entity.position.X ? SIZE_ONE_BLOCK : -SIZE_ONE_BLOCK;

            // Projectile is beneath entity
            if (pos.Y > entity.Bottom.Y)
            {
                // Use entity bottom
                pos.Y = entity.Bottom.Y;
            }
            
            // Projectile is above entity
            else if (pos.Y < entity.Top.Y)
            {
                // Use entity top
                pos.Y = entity.Top.Y;
            }

            // Projectile is left of entity
            if (pos.X < entity.Left.X)
            {
                // Use entity left
                pos.X = entity.Left.X;
            }

            // Projectile is right of entity
            else if (pos.X > entity.Right.X)
            {
                // Use entity right
                pos.X = entity.Right.X;
            }

            // Create the blood splat
            GoreNPC.newBlood(mod, pos, width, projectile.height, projectile.velocity, Config.absurdity_projectile_crit, scaleVel);


            // If it's a crit, penetrate the enemy and spawn extra blood
            if (crit)
            {
                float scaleVel_crit = Main.rand.NextFloat(0.3f, 0.6f);
                GoreNPC.newBlood(mod, pos, width, projectile.height, projectile.velocity, Config.absurdity_projectile_crit, scaleVel_crit);
            }

        }

        // Create a blood splat up when the player is hit by an NPC
        public override void OnHitByNPC(NPC npc, int damage, bool crit)
        {
            // Add some variance to where blood spawns
            const int VARIANCE_Y = 8;
            const int VARIANCE_Y_HALF = 4;

            // Spawn 
            Vector2 position = new Vector2(player.Left.X, player.Center.Y - VARIANCE_Y_HALF);

            // Velocity of blood is 3f up plus the player's velocity
            Vector2 velocity = new Vector2(0.0f, -3.0f) + player.velocity;

            // Create the blood splat
            GoreNPC.newBlood(mod, position, player.width, VARIANCE_Y, velocity, Config.absurdity_player_hit);
        }

        // Perform the kill effect when then player dies
        public override void Kill(double damage, int hitDirection, bool pvp, PlayerDeathReason damageSource)
        {
            // Add some variance to where blood spawns
            const int VARIANCE_Y = 8;
            const int VARIANCE_Y_HALF = 4;

            Vector2 position = new Vector2(player.Left.X, player.Center.Y - VARIANCE_Y_HALF);

            // Velocity of blood is 9f up plus the player's velocity
            Vector2 velocity = new Vector2(0.0f, -9.0f) + player.velocity;

            // Create the blood splat
            GoreNPC.newBlood(mod, position, player.width, VARIANCE_Y, velocity, Config.absurdity_player_kill);
        }

        // Create new blood when an enemy is hit by a projectile
        public override void OnHitByProjectile(Projectile proj, int damage, bool crit)
        {
            // The meat of the function lies in this function
            ProjectileAttackEntity(mod, proj, player, crit);
        }
    }
}
