using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;

namespace GoreGalore
{
    class GoreNPC : GlobalNPC
    {
        private const float ANGLE_RIGHT = 0.0f;
        private const float ANGLE_DOWN = (float)System.Math.PI / 2;
        private const float ANGLE_LEFT = (float)System.Math.PI;
        private const float ANGLE_UP = (float)(3 * System.Math.PI / 2);

        private const float ANGLE_DOWN_RIGHT = (float)System.Math.PI / 4;
        private const float ANGLE_DOWN_LEFT = (float)(3 * System.Math.PI / 4);
        private const float ANGLE_UP_LEFT = (float)(5 * System.Math.PI / 4);
        private const float ANGLE_UP_RIGHT = (float)(7 * System.Math.PI / 4);

        // Wrapper function - spawns blood at the specified position with the specified velocity
        public static void newBlood(Mod mod, Vector2 position, int width, int height, Vector2 velocity, int INT_ABSURDITY, float velocityScale = 1.0f)
        {
            string dustName = "GoreDust";
            for (int i = 0; i < INT_ABSURDITY; i++)
            {
                int index = Dust.NewDust(position, width, height, mod.DustType(dustName), velocity.X * velocityScale, velocity.Y * velocityScale, 255, Scale: 1.0f);
            }
        }

        // Called when an NPC is killed
        // Causes blood to explode from the NPC, with more extreme effects if the NPC is a boss NPC
        private void newBlood_kill(NPC npc)
        {
            // NPC wasn't a boss - normal behavior
            if (!npc.boss)
            {
                // Extract information about npc
                Vector2 position = new Vector2(npc.Left.X, npc.Top.Y);
                int width = npc.width;
                int height = npc.height;

                // Velocity of blood is 3f up plus the NPC's velocity
                // (oldVelocity is used to ignore the effect of knockback)
                Vector2 velocity = new Vector2(0f, -3f) + npc.oldVelocity;

                // Absurdity is retrieved from Config
                int INT_ABSURDITY = (int)(System.Math.Max(npc.width, npc.height) * Config.multiplier_kill);

                string dustName = "GoreDust";

                for (int i = 0; i < INT_ABSURDITY; i++)
                {
                    Dust.NewDust(position, width, height, mod.DustType(dustName), velocity.X, velocity.Y, 255, Scale: 1.0f);
                }
            }

            // NPC was a boss - have a little more fun
            else
            {
                // Extract information about boss
                Vector2 position = new Vector2(npc.Left.X, npc.Top.Y);
                int width = npc.width;
                int height = npc.height;

                // Velocity of blood is 10f up plus the NPC's velocity
                // (oldVelocity is used to ignore the effect of knockback)
                Vector2 velocity = new Vector2(0f, -10f) + npc.oldVelocity;

                // Absurdity is retrieved from Config
                // We divide the absurdity by 3f because 9 individual bloods are spawned for each iteration of the blood loop
                int INT_ABSURDITY = (int)(System.Math.Max(npc.width, npc.height) * Config.multiplier_kill_boss / 3f);

                string dustName = "GoreDust";

                for (int i = 0; i < INT_ABSURDITY; i++)
                {
                    // Blood becomes increasingly more dramatic each iteration
                    float plus_x = (0.1f * i) + 3.0f;
                    float plus_y = (0.3f * i) + 3.0f;

                    Dust.NewDust(position, width, height, mod.DustType(dustName), velocity.X, velocity.Y, 255, Scale: 2.0f);
                    Dust.NewDust(position, width, height, mod.DustType(dustName), velocity.X + plus_x, velocity.Y, 255, Scale: 2.0f);
                    Dust.NewDust(position, width, height, mod.DustType(dustName), velocity.X - plus_x, velocity.Y, 255, Scale: 2.0f);

                    Dust.NewDust(position, width, height, mod.DustType(dustName), velocity.X, velocity.Y - plus_y, 255, Scale: 2.0f);
                    Dust.NewDust(position, width, height, mod.DustType(dustName), velocity.X + plus_x, velocity.Y - plus_y, 255, Scale: 2.0f);
                    Dust.NewDust(position, width, height, mod.DustType(dustName), velocity.X - plus_x, velocity.Y - plus_y, 255, Scale: 2.0f);

                    Dust.NewDust(position, width, height, mod.DustType(dustName), velocity.X, velocity.Y - plus_y, 255, Scale: 2.0f);
                    Dust.NewDust(position, width, height, mod.DustType(dustName), velocity.X + plus_x, velocity.Y - plus_y, 255, Scale: 2.0f);
                    Dust.NewDust(position, width, height, mod.DustType(dustName), velocity.X - plus_x, velocity.Y - plus_y, 255, Scale: 2.0f);
                }
            }

        }

        // Returns a randomized vector corresponding to the given angle in radians
        public static Vector2 velocityFromAngle(float _angle, float scale = 1.0f)
        {
            double angle = _angle;
            Vector2 velocity = new Vector2((float)System.Math.Cos(angle), (float)System.Math.Sin(angle));

            return velocity * scale * Main.rand.NextFloat(0.8f, 1.2f);
        }

        // Perform the kill effect when we kill an NPC
        public override bool CheckDead(NPC npc)
        {
            if(base.CheckDead(npc))
            {
                newBlood_kill(npc);
                return true;
            }
            return false;
        }

        // Create new blood when an enemy is hit by a projectile
        // (The meat of this function lies in the GorePlayer class)
        public override void ModifyHitByProjectile(NPC npc, Projectile projectile, ref int damage, ref float knockback, ref bool crit, ref int hitDirection)
        {
            GorePlayer.ProjectileAttackEntity(mod, projectile, npc, crit);
        }

        // Create new blood every time you hit an NPC with an item
        // The type of item determines the behavior of the blood spawned
        public override void ModifyHitByItem(NPC npc, Player player, Item item, ref int damage, ref float knockback, ref bool crit)
        {
            // Whether or not the player is facing left
            bool left = (player.direction == -1);

            const int SIZE_ONE_BLOCK = 16;

            // Width of the blood splat has to be negative if we strike the right side of the NPC
            int width = player.position.X < npc.position.X ? SIZE_ONE_BLOCK : -SIZE_ONE_BLOCK;

            // Swinging, like a broadsword
            if (item.useStyle == 1)
            {
                // Determine point to spawn blood from
                float pos_x = player.position.X < npc.position.X ? npc.Hitbox.X : (npc.Right.X - SIZE_ONE_BLOCK);
                float pos_y;

                // Player is beneath NPC
                if (player.Top.Y >= npc.Top.Y)
                {
                    // Player is entirely below npc - use NPC bottom
                    if (player.Top.Y >= npc.Bottom.Y)
                    {
                        pos_y = npc.Bottom.Y;
                    }

                    // Player is not entirely beneath NPC - use player height
                    else
                    {
                        pos_y = player.Top.Y;
                    }
                }

                // Player is above NPC
                else
                {
                    // Use NPC top
                    pos_y = npc.Top.Y;
                }

                Vector2 pos = new Vector2(pos_x, pos_y);

                // Determine velocity with which to fire the blood, depending on which way the character is facing
                float velocity_angle = left ? Main.rand.NextFloat(ANGLE_UP_RIGHT, (float)(System.Math.PI * 2)) : Main.rand.NextFloat(ANGLE_LEFT, ANGLE_UP_LEFT);
                Vector2 velocity = velocityFromAngle(velocity_angle, 2.5f);

                // Create the blood splat
                newBlood(mod, pos, width, item.height, velocity, Config.absurdity_swing);

                // If it's a crit, penetrate the enemy and spawn extra blood
                if (crit)
                {
                    velocity = velocityFromAngle(left ? ANGLE_DOWN_LEFT : ANGLE_DOWN_RIGHT);
                    newBlood(mod, pos, width, item.height, velocity, Config.absurdity_swing_crit, 2.5f);
                }
            }


            // Stabbing, like a shortsword
            else if (item.useStyle == 3)
            {
                // Blood comes from center of player
                float pos_x = player.position.X < npc.position.X ? npc.Hitbox.X : (npc.Right.X - SIZE_ONE_BLOCK);
                float pos_y = player.Center.Y;
                Vector2 pos = new Vector2(pos_x, pos_y);

                // Determine velocity with which to fire the blood, depending on which way the character is facing
                float velocity_angle = left ? Main.rand.NextFloat(ANGLE_UP_RIGHT, ANGLE_RIGHT + (float)((System.Math.PI) * 2)) : Main.rand.NextFloat(ANGLE_LEFT, ANGLE_UP_LEFT);
                Vector2 velocity = velocityFromAngle(velocity_angle, 1.8f);

                // Create the blood splat
                newBlood(mod, pos, width, item.height, velocity, Config.absurdity_stab);

                // If it's a crit, penetrate the enemy and spawn extra blood
                if (crit)
                {
                    velocity = velocityFromAngle(left ? ANGLE_LEFT : ANGLE_RIGHT, 2.5f);
                    newBlood(mod, pos, width, item.height, velocity, Config.absurdity_stab_crit, 1.8f);
                }
            }

            // All else (excluding spears and yoyos - those are projectiles)
            else
            {
                // Spawn from center of enemy
                Vector2 pos = npc.Center;

                // Shoot blood directly up
                float velocity_angle = ANGLE_UP;
                Vector2 velocity = velocityFromAngle(velocity_angle);

                // Create the blood splat
                newBlood(mod, pos, width, item.height, velocity, Config.absurdity_item_default);

                // If it's a crit, just spawn more blood (but make it faster)
                if (crit)
                {
                    velocity = velocityFromAngle(ANGLE_UP);
                    newBlood(mod, pos, width, item.height, velocity, Config.absurdity_item_default_crit, 2.0f);
                }
            }
        }

    }
}