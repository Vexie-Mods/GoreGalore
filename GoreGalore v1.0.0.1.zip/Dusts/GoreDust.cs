using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;

namespace GoreGalore.Dusts
{
    class GoreDust : ModDust
    {
        // How much to decrease the scale of a blood particle on each frame
        private float scaleDown_solid = 0.005f;

        // How much to increase the y velocity of a blood particle on each frame
        private static float gravity = 0.3f;

        // Below this scale value, the dust will disappear
        private static float threshold_scale = 0.4f;


        // Returns true if the dust particle is on a solid block, false otherwise
        private bool checkSolidBlock(Dust dust)
        {
            Vector2 pos = dust.position;

            if (!Collision.SolidCollision(pos, 1, 1))
            {
                return false;
            }
            return true;
        }

        public override void OnSpawn(Dust dust)
        {
            dust.noGravity = false;
            dust.noLight = true;

            // Give blood particle a small boost up on spawn
            dust.velocity.Y -= 1.2f;

            // Solid collision on spawn - push up 1 block
            if (Collision.SolidCollision(dust.position, 1, 1))
            {
                dust.position.Y -= 16f;
            }
        }

        public override bool Update(Dust dust)
        {
            // Not on solid block - apply gravity and rotation
            if (!checkSolidBlock(dust))
            {
                dust.velocity.Y += gravity;
                dust.position += dust.velocity;
                dust.rotation += dust.velocity.X;
            }

            // On solid block - reset velocity, scale dust down, and check to see if it's too small 
            else
            {
                if(dust.velocity != Vector2.Zero)
                {
                    dust.velocity = Vector2.Zero;
                }

                // Very slowly creep downward - gives dripping from ceiling and walls effect
                dust.position.Y += 0.03f;

                // Scale dust down
                dust.scale -= scaleDown_solid;

                // If the dust is too small, remove the dust
                if (dust.scale < threshold_scale)
                {
                    dust.active = false;
                }
            }

            // This hasn't proven to be a problem
//          if(dust.position.Y > Main.maxTilesY)
//          {
//              dust.active = false;
//          }

            return false;
        }

        public override Color? GetAlpha(Dust dust, Color lightColor)
        {
            return new Color(lightColor.R, lightColor.G, lightColor.B, 255);
        }
    }
}