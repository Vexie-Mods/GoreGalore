using Microsoft.Xna.Framework;
using Terraria;
using Terraria.IO;
using Terraria.ModLoader;
using System.IO;

// Based on goldenapple's mod config tutorial
// https://forums.terraria.org/index.php?threads/modders-guide-to-config-files-and-optional-features.48581/

namespace GoreGalore
{
    public static class Config
    {
        // float values - Multiplies the default value by the fixed amount specified
        // Killing npcs has slightly different functionality, so these values are expressed as float multipliers
        // instead of integer values representing how many blood dusts to spawn
        public static float multiplier_kill = 1.0f;
        public static float multiplier_kill_boss = 1.0f;

        // int values - Number of dusts to spawn during corresponding event
        public static int absurdity_player_hit = 25;
        public static int absurdity_player_kill = 40;

        public static int absurdity_projectile = 10;
        public static int absurdity_swing = 10;
        public static int absurdity_stab = 20;
        public static int absurdity_item_default = 10;

        public static int absurdity_projectile_crit = 20;
        public static int absurdity_swing_crit = 20;
        public static int absurdity_stab_crit = 20;
        public static int absurdity_item_default_crit = 20;

        //The file will be stored in "Terraria/ModLoader/Mod Configs/GoreGalore.json"
        static string ConfigPath = Path.Combine(Main.SavePath, "Mod Configs", "GoreGalore.json");

        static Preferences Configuration = new Preferences(ConfigPath);

        public static void Load()
        {
            //Reading the config file
            bool success = ReadConfig();

            if (!success)
            {
                ErrorLogger.Log("Failed to read Example Mod's config file! Recreating config...");
                CreateConfig();
            }
        }

        //Returns "true" if the config file was found and successfully loaded.
        static bool ReadConfig()
        {
            if (Configuration.Load())
            {
                Configuration.Get("Multiplier_Kill", ref multiplier_kill);
                Configuration.Get("Multiplier_Kill_Boss", ref multiplier_kill_boss);

                Configuration.Get("Gore_Player", ref absurdity_player_hit);
                Configuration.Get("Gore_Kill_Player", ref absurdity_player_kill);

                Configuration.Get("Gore_Projectile", ref absurdity_projectile);
                Configuration.Get("Gore_Swing", ref absurdity_swing);
                Configuration.Get("Gore_Stab", ref absurdity_stab);
                Configuration.Get("Gore_Item_Default", ref absurdity_item_default);

                Configuration.Get("Gore_Projectile_Crit", ref absurdity_projectile_crit);
                Configuration.Get("Gore_Swing_Crit", ref absurdity_swing_crit);
                Configuration.Get("Gore_Stab_Crit", ref absurdity_stab_crit);
                Configuration.Get("Gore_Item_Default_Crit", ref absurdity_item_default_crit);

                return true;
            }
            return false;
        }

        //Creates a config file. This will only be called if the config file doesn't exist yet or it's invalid. 
        static void CreateConfig()
        {
            Configuration.Clear();

            Configuration.Put("Multiplier_Kill", multiplier_kill);
            Configuration.Put("Multiplier_Kill_Boss", multiplier_kill_boss);

            Configuration.Put("Gore_Player", absurdity_player_hit);
            Configuration.Put("Gore_Kill_Player", absurdity_player_kill);

            Configuration.Put("Gore_Projectile", absurdity_projectile);
            Configuration.Put("Gore_Swing", absurdity_swing);
            Configuration.Put("Gore_Stab", absurdity_stab);
            Configuration.Put("Gore_Item_Default", absurdity_item_default);

            Configuration.Put("Gore_Projectile_Crit", absurdity_projectile_crit);
            Configuration.Put("Gore_Swing_Crit", absurdity_swing_crit);
            Configuration.Put("Gore_Stab_Crit", absurdity_stab_crit);
            Configuration.Put("Gore_Item_Default_Crit", absurdity_item_default_crit);



            Configuration.Save();
        }
    }
}